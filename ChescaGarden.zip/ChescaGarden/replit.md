# Overview

This is a full-stack web application built with Express.js backend and React frontend. The project appears to be a personal landing page for "QueenChescaX" featuring animated UI elements and external service integrations. The application uses modern TypeScript, Tailwind CSS for styling, and includes a complete UI component library based on shadcn/ui with Radix UI primitives.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with simple path-based navigation
- **State Management**: TanStack Query (React Query) for server state management and API data fetching
- **UI Framework**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and custom animations
- **Forms**: React Hook Form with Zod validation through @hookform/resolvers
- **Animations**: Framer Motion for interactive animations and transitions

## Backend Architecture
- **Framework**: Express.js with TypeScript using ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Pattern**: Repository pattern with abstract IStorage interface allowing for both memory and database implementations
- **API Design**: RESTful endpoints with centralized route registration
- **Development**: Hot module replacement via Vite integration in development mode

## Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database queries
- **Schema**: Centralized schema definition in shared directory with Zod validation
- **User Model**: Simple user entity with UUID primary keys, username, and password fields
- **Migrations**: Drizzle Kit for database schema migrations and versioning

## Development Setup
- **Monorepo Structure**: Shared code between client and server with TypeScript path mapping
- **Build Process**: Vite for frontend bundling, esbuild for server compilation
- **Development Server**: Express with Vite middleware for hot reloading and development features
- **Type Safety**: Strict TypeScript configuration with shared types between frontend and backend

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL database using @neondatabase/serverless driver
- **Connection**: Environment-based database URL configuration with connection pooling

## UI and Animation Libraries
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives for components
- **Framer Motion**: Animation library for React providing declarative animations
- **Lucide React**: Icon library providing consistent iconography throughout the application
- **Embla Carousel**: Carousel/slider functionality for image galleries or content rotation

## Development and Build Tools
- **Vite**: Frontend build tool with plugin ecosystem for development and production builds
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer plugins
- **Replit Integration**: Development environment integration with runtime error handling and cartographer plugins

## Utility Libraries
- **date-fns**: Date manipulation and formatting utilities
- **clsx & tailwind-merge**: Conditional CSS class name utilities for dynamic styling
- **nanoid**: URL-safe unique string ID generator for various application needs

## External Service Integrations
- **Roblox Game Integration**: Direct links to specific Roblox game experiences with private server support
- **Discord Integration**: User profile linking for community engagement and social features